New Project Extension
=============


This Extension provides a platform for creating new projects for [Brackets](https://github.com/adobe/brackets).  
I have a lot of ideas of where I want this to go but wanted to get it out there for folks to play with and hopefully extend.

Feel free to fork this repository and contribute back to this project.  

My goal is to see have folks authoring and sharing new project templates through this repository.


